package gcatech.net.documentcapturepicture.annotations

annotation class LabelTitle(val labelValue: String)