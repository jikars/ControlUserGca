package gcatech.net.documentcapturepicture.annotations

annotation class MapValue(val valueMapping: String)