package gcatech.net.documentcapturepicture.annotations



annotation class Key
