package gcatech.net.documentcapturepicture.scanners.ocr

interface IResultOcr {
    fun resultOcr(result : String?)
}