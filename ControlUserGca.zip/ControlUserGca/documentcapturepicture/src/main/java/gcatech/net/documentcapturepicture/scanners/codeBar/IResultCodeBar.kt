package gcatech.net.documentcapturepicture.scanners.codeBar

interface IResultCodeBar {
    fun resultCodeBar(result : String?)
}